import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PersonService {

  constructor(private http: HttpClient) { }

  getAllPerson(): any {
    return this.http.get<any[]>('https://tekdi-challenges.appspot.com/api/People');
  }

  getByPersonId(id): any {
    return this.http.get<any[]>('https://tekdi-challenges.appspot.com/api/People/'+id);
  }

  addPersonData(personForm):any{
    console.log("in server"+personForm)
    return this.http.post('https://tekdi-challenges.appspot.com/api/People', personForm);
  }
}
