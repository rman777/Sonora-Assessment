import { Component, OnInit } from '@angular/core';

import { PersonService } from 'src/app/service/person.service';

@Component({
  selector: 'app-person',
  templateUrl: './person.component.html',
  styleUrls: ['./person.component.css']
})
export class PersonComponent implements OnInit {

    
    constructor(private personService: PersonService) { }
    personList: any[];
    updateData: any;
    ngOnInit() {
     this.getAll();
 }


    getAll(): void {
      this.personService.getAllPerson()
      .subscribe((response) => {
        this.personList = response;
      });
    }

    getPersonDetails(id){
      this.personService.getByPersonId(id)
      .subscribe((response) => {
        this.updateData = response;
        alert(this.updateData);
      });
    }

    

}
