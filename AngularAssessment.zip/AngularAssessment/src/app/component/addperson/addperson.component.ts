import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PersonService } from 'src/app/service/person.service';

@Component({
  selector: 'app-addperson',
  templateUrl: './addperson.component.html',
  styleUrls: ['./addperson.component.css']
})
export class AddpersonComponent implements OnInit {

  personForm: FormGroup;
  submitted = false;

  countries: string[] = [
    'IN',
    'AUS',
    'SL',
    'PAK',
    'USA'
  ];

  constructor(private formBuilder: FormBuilder,private personService: PersonService) { }

  ngOnInit() {
     this.emptyForm();
  }

  emptyForm(){
    this.personForm = this.formBuilder.group({
      name: ['', Validators.required],
      file: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      country: [''],
      dob:['']
    });
  }

  onFileChange(event) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      alert(file)
      this.personForm.patchValue({
        file: file
      });
    }
  }

  get f() { return this.personForm.controls; }

  onSubmit() {

    // const formData = new FormData();
    // formData.append('file', this.personForm.get('file').value);


      this.submitted = true;
      if (this.personForm.invalid) {
          return;
      }
      this.personService.addPersonData(this.personForm.value)
      .subscribe((response) => {
        console.log(response)
        alert('Person added Successfully.');
        this.emptyForm();
      });

  }


}
