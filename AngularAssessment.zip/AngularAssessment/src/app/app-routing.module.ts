import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddpersonComponent } from './component/addperson/addperson.component';
import { PersonComponent } from './component/person/person.component';

const routes: Routes = [
  {path: '', component: PersonComponent},
  {path: 'addperson', component: AddpersonComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
